# SPTWSVM
Improved Sparse Pinball Twin Support Vector Machine
